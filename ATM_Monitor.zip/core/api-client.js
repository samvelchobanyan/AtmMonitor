// api-client.js
import { BASE_PATH } from "./config.js";

export class ApiClient {
    constructor({ baseUrl, useProxy = false, delay = null }) {
        this.baseUrl = baseUrl;
        this.useProxy = useProxy;
        this.delay = delay;
    }

    buildUrl(endpoint, params = {}) {
        const base = this.baseUrl + (endpoint.startsWith("/") ? endpoint : `/${endpoint}`);
        const qs = new URLSearchParams(params).toString();
        const full = qs ? `${base}?${qs}` : base;
        const delay = this.delay !== null ? `delay=${this.delay}&` : "";
        return this.useProxy
            ? `${window.location.origin}${BASE_PATH}/proxy.php?${delay}url=${encodeURIComponent(full)}`
            : full;
    }

    getAuthHeaders(extraHeaders = {}) {
        const token = sessionStorage.getItem("auth_token");
        const authHeader = token ? { Authorization: `Bearer ${token}` } : {};
        return { ...authHeader, ...extraHeaders };
    }

    async get(endpoint, params = {}, headers = {}, asBlob) {
        const url = this.buildUrl(endpoint, params);
        const res = await fetch(url, { headers: this.getAuthHeaders(headers) });
        // if file
        if (asBlob) {
            return res;
        }

        return this.handle(res);
    }

    async post(endpoint, body = {}, headers = {}) {
        const url = this.buildUrl(endpoint);
        const res = await fetch(url, {
            method: "POST",
            headers: this.getAuthHeaders({
                "Content-Type": "application/json",
                ...headers,
            }),
            body: JSON.stringify(body),
        });
        return this.handle(res);
    }

    async postForm(endpoint, formData, headers = {}) {
        const url = this.buildUrl(endpoint);
        const res = await fetch(url, {
            method: "POST",
            body: formData,
            headers: this.getAuthHeaders(headers), // don't set Content-Type manually
        });
        return this.handle(res);
    }

    async handle(res) {
        const type = res.headers.get("Content-Type") || "";
        const isJson = type.includes("application/json");
        const data = isJson ? await res.json() : await res.text();

        if (res.status === 401 && sessionStorage.getItem("auth_token")) {
            sessionStorage.removeItem("auth_token"); // clear invalid token
            // if (!window.location.pathname.includes("signin")) {
            window.location.href = "signin";
            // }

            return;
        }
        if (!res.ok) {
            const err = new Error(`API ${res.status}`);
            err.status = res.status;
            err.data = data;
            throw err;
        }

        return data;
    }
}

// export default client for most use-cases
export const api = new ApiClient({
    baseUrl: "monitoring.ardshinbank.am/backend",
    // baseUrl: "https://atmmonitorapi-production.up.railway.app/api",
    // baseUrl: 'http://37.186.122.133:3393/api',
    // baseUrl: `${window.location.origin}${BASE_PATH}`,
    useProxy: false,
});

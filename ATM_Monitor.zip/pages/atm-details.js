import { DynamicElement } from "../core/dynamic-element.js";
import "../components/ui/infoItem.js";
import "../components/dynamic/chartComponent.js";
import "../components/dynamic/doughnutTabs.js";
import encode from "../assets/js/utils/encode.js";
import "../components/ui/atmItem.js";
import "../components/ui/infoItem.js";
import "../components/dynamic/simpleTable.js";
import "../components/dynamic/simpleGrid.js";
import { formatDate } from "../core/utils/date-transformer.js";

class AtmDetails extends DynamicElement {
    constructor() {
        super();

        this.state = {
            summary: null,
        };
        this.atmId = "";
        this.exchangeDateBox = null;
        this.encashmentDateBox = null;
        this.depositChart = null;
        this.worktimeChart = null;
        this.atmInfo = null;
    }

    onConnected() {
        this.atmId = this.getAttribute("id");
        this.fetchAtm();
        this.fetchEncashmentsInfocardData();
        this.fetchAtmInfoData();
    }

    onAfterRender() {
        this.exchangeDateBox = this.$("#exchange-date");
        this.encashmentDateBox = this.$("#encashment-date");
        this.depositChart = this.$("#bar-chart-2");
        this.worktimeChart = this.$("#worktime-bar-chart");
    }

    addEventListeners() {
        this.encashmentChanges();
        this.workTimeChanges();

        this.showDepositPopups();

        if (this.exchangeDateBox) {
            this.addListener(this.exchangeDateBox, "date-range-change", (e) => {
                const { startDate, endDate } = e.detail;
                this.fetchExchangeData(startDate, endDate);
            });

            // element is in header, but needs call here
            let infoButton = document.querySelector("#info");
            if (infoButton)
                this.addListener(infoButton, "click", async () => {
                    await this.fetchModels();
                    await this.fetchCimTypes();
                    await this.fetchTypes();
                    this.openAtmInfoPopup();
                });
        }
    }

    async fetchAtmInfoData() {
        const response = await this.fetchData(`/atm/getatm/${this.atmId}`);
        this.atmInfo = response.data;
    }

    async fetchModels() {
        try {
            const response = await this.fetchData(`/atm/models`);
            const model = response.data.find((m) => m.id === this.atmInfo.model_id);
            this.atmInfo.model_id = model ? model.model_name : "-";
        } catch (err) {
            console.error("❌ Error fetching models:", err);
        }
    }

    async fetchCimTypes() {
        try {
            const response = await this.fetchData(`/atm/cim-types`);
            const cim = response.data.find((c) => c.id === this.atmInfo.atm_cim_type);
            this.atmInfo.atm_cim_type = cim ? cim.name : "-";
        } catch (err) {
            console.error("❌ Error fetching cimTypes:", err);
        }
    }

    async fetchTypes() {
        try {
            const response = await this.fetchData(`/atm/atm-types`);
            const type = response.find((c) => c.id === this.atmInfo.atm_type);
            this.atmInfo.atm_type = type ? type.type_Name : "-";
        } catch (err) {
            console.error("❌ Error fetching types:", err);
        }
    }

    showDepositPopups() {
        if (this.depositChart) {
            this.addListener(this.depositChart, "chart-bar-clicked", (e) => {
                let cassetteId = e.detail.cassette_id;
                let label = e.detail.columnLabel.substring(0, e.detail.columnLabel.indexOf("-"));

                let link = "";
                if (label == "DC") {
                    link = "/atm/deposit-cassette-contents";
                } else if (label.includes("RJ")) {
                    link = "/atm/reject-cassette-contents";
                } else if (label.includes("RT")) {
                    link = "/atm/retract-cassette-contents";
                }

                const labelName = e.detail.columnLabel.replace(/[^A-Za-z]/g, "");
                if (link) this.fetchRejectedCasPopUpData(link, labelName, cassetteId);
            });
        }
    }

    workTimeChanges() {
        if (this.worktimeChart) {
            this.addListener(this.worktimeChart, "chart-changed", (e) => {
                let data = e.detail.data;
                let atmWorkingPercent = this.$("#atm_working_percent");
                let atmNonWorkingPercent = this.$("#atm_non_working_percent");
                let atmLastDisconnect = this.$("#atm_last_disconnect");
                let atmLastConnect = this.$("#atm_last_connect");
                let atmLastStatusDuration = this.$("#atm_last_status_duration");

                atmWorkingPercent?.setAttribute("value", `${data.total_working_percent}%`);
                atmNonWorkingPercent?.setAttribute("value", `${data.total_non_working_percent}%`);
                atmLastDisconnect?.setAttribute("value", formatDate(data.last_disconnect));
                atmLastConnect?.setAttribute("value", formatDate(data.last_connect));
                atmLastStatusDuration?.setAttribute("value", data.last_status_duration);
            });
        }
    }

    encashmentChanges() {
        if (this.encashmentDateBox) {
            this.addListener(this.encashmentDateBox, "date-range-change", (e) => {
                const { startDate, endDate } = e.detail;
                let date_query = `startDate=${startDate}&endDate=${endDate}`;
                let link = `/encashment/summary?atmIds=${this.atmId}&${date_query}`;
                this.$("simple-grid").setAttribute("data-source", link);
                this.fetchEncashmentsInfocardData(date_query);
            });
        }
    }

    async fetchExchangeData(startDate, endDate) {
        const response = await this.fetchData(
            `/analytics/exchange-summary-in-days?startDate=${startDate}&endDate=${endDate}&atmId=${this.atmId}`
        );
        const currencies = response.data.currency_details;

        currencies.forEach((currency) => {
            const el = this.$(`#${currency.currency_code}`);
            if (el) {
                el.setAttribute("value", currency.total_amount);
                el.setAttribute("trend", currency.total_amount_percent_change);
            }
        });
    }

    async fetchRejectedCasPopUpData(link, popUpName, cassetteId) {
        const response = await this.fetchData(`${link}?atmId=${this.atmId}&type=${cassetteId}`);
        const data = response.data?.totals;

        this.openRejectedPopUp(data, popUpName);
    }

    openRejectedPopUp(data, name) {
        const modal = document.createElement("modal-popup");
        document.body.appendChild(modal);
        let title = "";
        if (name == "RT") {
            title = "Retract casset";
        } else if (name == "RJ") {
            title = "Reject casset";
        } else if (name == "DC") {
            title = "Deposit casset";
        }

        const cards = data
            ?.map((item) => {
                const buttonAttr = name === "DC" ? `button-text="Մանրամասն"` : "";
                return `
                <info-card
                    title="${item.currency}"
                    value="${item.amount}"
                    show-border="true"
                    ${buttonAttr}
                ></info-card>
            `;
            })
            .join("");

        modal.renderModal({
            title,
            bodyClass: "modal__chart",
            bodyContent: `
               ${data != undefined && data.length != 0 ? cards : "Տվյալներ չկան"}
                `,
        });
        if (name === "DC") {
            const infoCards = modal.querySelectorAll("info-card");

            infoCards.forEach((card) => {
                card.addEventListener("click", async () => {
                    const currency = card.getAttribute("title");

                    if (!this.atmId || !currency) return;

                    try {
                        const response = await this.fetchData(
                            `/atm/deposit-notes-info?atmId=${this.atmId}&currencyCode=${currency}`
                        );

                        this._openCasseteExchangePopup(response.data);
                    } catch (error) {
                        console.error("Failed to fetch incashment data:", error);
                    }
                });
            });
        }
    }

    _openCasseteExchangePopup(data) {
        const modal = document.createElement("modal-popup");
        document.body.appendChild(modal);

        const processedData = data.map((item) => ({
            ...item,
            result: (item.denomination ?? 0) * (item.count ?? 0),
        }));

        modal.renderModal({
            title: "Մանրամասն",
            bodyContent: `
                <list-view items='${JSON.stringify(processedData)}'>
                    <template>
                    <div class="modal__exch">
                        <div class="modal__incashment-text">{{denomination}}</div>
                        <div class="modal__incashment-text">{{count}} հատ</div>
                        <div class="modal__incashment-text">{{result}}</div>
                        <div class="modal__incashment-text">{{description}}</div>
                    </div>
                    </template>
                </list-view>
                `,
        });
    }

    openAtmInfoPopup() {
        let info = this.atmInfo;

        const modal = document.createElement("modal-popup");
        document.body.appendChild(modal);
        modal.setContent(`
        <div class="modal__header">
            <div class="modal__title">
              <div>ATM #${this.atmId}</div>
                  <div class="flex flex-row align-middle location-line" style="margin-top:12px" >
                    <p>
                      <span class="atm-item__label">Քաղաք՝</span>
                      <span class="atm-item__value">${info.city}</span>
                    </p>

                    <p style="margin: 0 12px">
                      <span class="atm-item__label">Համայնք՝</span>
                      <span class="atm-item__value">${info.district}</span>
                    </p>

                    <p>
                      <span class="atm-item__label">Հասցե՝</span>
                      <span class="atm-item__value">${info.address}</span>
                    </p>
                  </div>
            </div>
            <img class="modal__close" src="assets/img/icons/x-circle.svg" alt="" />
        </div>
         <div class="modal__body atm_info">
            <div class="align-between row">
                <p class="atm-item__label">Մոդել՝</p>
                <p class="atm-item__value">${this.atmInfo.model_id}</p>
            </div>
            <div class="align-between row">
                <p class="atm-item__label">IP հասցե՝</p>
                <p class="atm-item__value">${info.ip_address ?? "-"}</p>
            </div>
            <div class="align-between row">
                <p class="atm-item__label">Տեսակ՝</p>
                <p class=" atm-item__value">${this.atmInfo.atm_type}</p>
            </div>
            <div class="align-between row">
                <p class="atm-item__label">CIM Տեսակ՝</p>
                <p class="atm-item__value">${this.atmInfo.atm_cim_type}</p>
            </div>
            </div>
    
   
    `);

        // Add close button listener
        const closeBtn = modal.querySelector(".modal__close");
        closeBtn?.addEventListener("click", () => modal.remove());
    }

    async fetchAtm() {
        const today = new Date().toISOString().split("T")[0];

        try {
            const response = await this.fetchData(
                `/atm/my-profile?atmId=${this.atmId}&StartDate=${today}`
            );

            this.setState({
                summary: response.data,
            });

            // add to header atm name instead of atm id
            this.setHeaderInfo();
        } catch (err) {
            console.error("❌ Error fetching summary:", err);
            this.setState({ summary: null });
        }
    }

    setHeaderInfo() {
        let atm = this.atmInfo;

        let pageTitle = document.querySelector("#title");
        pageTitle.textContent = `ATM #${atm.name}`;

        // set to header correct connection status
        let connectionStatusEl = document.querySelector("#connection_status");
        const isConnected = atm.connection_status_id == "1";       
        const connectedStatus = isConnected ? "Կապի մեջ" : "Կապից դուրս";
        const connectionStatusClass = isConnected
        ? "atm-item__status_working"
        : "atm-item__status_not-working";
        
        
        if (connectionStatusEl) {
            connectionStatusEl.className = `atm-item__status ${connectionStatusClass || ""}`;
            const span = connectionStatusEl.querySelector("span");
            if (span) {
                span.textContent = connectedStatus || "";
            }
        } 
        
        // set to header correct working status
        let workingStatusEl = document.querySelector("#working_status");
        const isWorking = atm.working_status_id == "1";
        const workingStatus = isWorking ? "Աշխատում է" : "Չի աշխատում";
        const workingStatusClass = isWorking
        ? "atm-item__status_working"
        : "atm-item__status_not-working";

        if (workingStatusEl) {
            workingStatusEl.className = `atm-item__status ${workingStatusClass || ""}`;
            const span = workingStatusEl.querySelector("span");
            if (span) {
                span.textContent = workingStatus || "";
            }
        }
    }

    async fetchEncashmentsInfocardData(date_query = "") {
        try {
            const failedResponse = await this.fetchData(
                `/encashment/failed-transactions?atmIds=${this.atmId}&${date_query}`
            );
            const totalsResponse = await this.fetchData(
                `/encashment/totals?atmIds=${this.atmId}&${date_query}`
            );

            const data = { ...failedResponse.data, ...totalsResponse.data };

            const failedCount = this.$("#failed-count");
            const failedAmount = this.$("#failed-amount");
            const incCount = this.$("#inc_count");
            const collectedAmount = this.$("#collected_amount");
            const encachmentAmount = this.$("#encachment_amount");

            failedCount?.setAttribute("value", data.failed_transactions_count);
            failedAmount?.setAttribute("value", data.failed_transactions_amount);
            incCount?.setAttribute("value", data.total_count);
            collectedAmount?.setAttribute("value", data.total_collected_amount);
            encachmentAmount?.setAttribute("value", data.total_encachment_amount);
        } catch (err) {
            console.error("❌ Error fetching failed incashments:", err);
            // this.setState({ summary: null });
        }
    }

    template() {
        if (!this.state.summary) {
            return /*html*/ `
            <div class="row">
                <div class="column sm-12">
                    <div class="loading">
                        <div class="loading__spinner spinner"></div>
                        <div class="loading__text">Տվյալները բեռնվում են…</div>
                    </div>
                </div>
            </div>
            `;
        }

        const data = this.state.summary;

        const dispenseData = encode(data.transactions_summary.dispense_summary);
        const depositData = encode(data.transactions_summary.deposit_summary);
        const exchangeData = data.transactions_summary.exchange_summary.currency_details;

        const balanceInfo = data.balance_info;
        const nominalList = balanceInfo.cassettes.filter((c) => c.nominal === 0);
        const modelList = balanceInfo.cassettes.filter((c) => c.nominal !== 0);

        const transactionDynamics = encode(
            data.transactions_summary.transaction_dynamics.overall_dynamic.hourly_data
        );

        const incData = balanceInfo.cassettes
            .filter((item) => item && item.nominal !== 0)
            .map((item) => {
                const banknoteName = item.nominal;
                const countDiff = item.last_encashment_count ?? 0;

                return {
                    banknot_name: banknoteName.toLocaleString(),
                    count: countDiff,
                    result: `${(banknoteName * countDiff).toLocaleString()} ֏`,
                };
            });

        const devicesData = data.devices;
        const atmWorkHours = data.atm_work_hours;

        return /*html*/ `
          <div class="row align-middle" style="margin-bottom: 16px;">
            <div class="column shrink" style="margin-right: 16px;">
              <span class="atm-item__label">Քաղաք՝</span>
              <span class="atm-item__value">${balanceInfo.city}</span>
            </div>

            <div class="column shrink" style="margin-right: 16px;">
              <span class="atm-item__label">Համայնք՝</span>
              <span class="atm-item__value">${balanceInfo.district}</span>
            </div>

            <div class="column shrink">
              <span class="atm-item__label">Հասցե՝</span>
              <span class="atm-item__value">${balanceInfo.address}</span>
            </div>
          </div>

            <div class="row">
                <div class="column sm-12">
                   <div class="container">
                    <container-top icon="icon-bar-chart" title="Բանկոմատում առկա գումար"> </container-top>
                    <div class="row">
                        <div class="column sm-6">
                            <div class="infos infos_margin">
                                <info-card title="Մնացորդ" value="${
                                    data.balance_info.total_balance
                                }" value-currency="֏" value-color="color-green" trend="7" show-border="true"> </info-card>
                            </div>
                            <chart-component id="bar-chart-1" chart-data="${encode(
                                modelList
                            )}" chart-type="bar" show-date-selector="false"></chart-component>
                        </div>

                         <div class="column sm-6">
                            <div class="infos infos_margin">
                                 <info-card
                                    title="Վերջին ինկասացիա (${formatDate(
                                        data.balance_info.last_encashment_date
                                    )})"
                                    value="${data.balance_info.last_encashment_amount}"
                                    value-currency="֏"
                                    value-color="color-blue"
                                    show-border="true"
                                    button-text="Մանրամասն"
                                    incashment-data='${encode(incData)}'
                                >
                                </info-card>
                            </div>
                            <chart-component id="bar-chart-2" chart-data="${encode(
                                nominalList
                            )}" chart-type="bar" show-date-selector="false"></chart-component>
                        </div>
                    </div>

                    </div>
                    </div>
                <div class="column sm-12">
                    <div class='row'>
                        <div class="column sm-6">
                            <div class="container">
                                <doughnut-tabs id="dispense" data="${dispenseData}" title="Կանխիկացում"
                                api-url="/analytics/dispense-summary-in-days?atmId=${
                                    this.atmId
                                }"></doughnut-tabs>
                            </div>
                        </div>
                        <div class="column sm-6">
                            <div class="container">
                                <doughnut-tabs id="deposit" data="${depositData}" title="Մուտքագրում"
                                 api-url="/analytics/deposit-summary-in-days?atmId=${
                                     this.atmId
                                 }"></doughnut-tabs>
                            </div>
                    </div>
                   </div>
                   <div class="column sm-12">
                       <div class="container">
                        <div class="select-container">
                           <container-top icon="icon-dollar-sign" title="Արտարժույթի փոխանակում"></container-top>
                            <select-box-date id='exchange-date'></select-box-date>
                        </div>
                           <div class="infos">
                               ${exchangeData
                                   .map((exchange) => {
                                       return `
                                   <info-card
                                       id="${exchange.currency_code}"  
                                       title="${exchange.currency_code}"
                                       value="${exchange.total_amount}"
                                       trend="${exchange.total_amount_percent_change}"
                                       icon="icon icon-box"
                                       show-border="true"></info-card>`;
                                   })
                                   .join("")}
                           </div>
                         </div>
                    </div>

                      <div class="column sm-12">
                    <div class="container">
                        <container-top icon="icon-chart" title="Գործարքների դինամիկա"></container-top>
                        <chart-component 
                            id="line-chart-transactions" 
                            chart-type="line" 
                            chart-data='${transactionDynamics}' 
                            api-url="/analytics/transactions-dynamic-in-days?atmIds=${this.atmId}" 
                            ${this.attrIf("city", this.state.currentCity)} 
                            ${this.attrIf("region", this.state.currentRegion)}> </chart-component>
                    </div>
                </div>

                 
                 <div class="row">
            <div class="column sm-6">
                <div class="container">
                    <container-top icon="icon-cpu" title="Սարքավորումներ"> </container-top>
                    <div class="info-items">
                    ${devicesData
                        .map((device) => {
                            return `<info-item text="${device.device_type}" data-working="${
                                device.status == 1 ? true : false
                            }"></info-item>`;
                        })
                        .join("")}
                    </div>
                </div>
            </div>
            <div class="column sm-6">
                <div class="container">
                    <container-top icon="icon-trello" title="Արտադրողականություն"> </container-top>
                    <div class="infos infos_margin">
                       <info-card
                            title="Աշխատաժամանակ" 
                            id= 'atm_working_percent'
                            value="${atmWorkHours.work_hours_per_day[0]?.working_percent}%"
                            icon="icon icon-clock"
                            show-border="true"></info-card>
                        <info-card
                            title="Խափանում"
                            id= 'atm_non_working_percent'
                            value="${atmWorkHours.work_hours_per_day[0]?.non_working_percent}%"
                            icon="icon icon-clock"
                            show-border="true"></info-card>
                    </div>
                    <div class="info-items-container">
                        <div class="info-items info-items_col">
                         <info-item text="Վերջին Disconnect" id='atm_last_disconnect' value="${formatDate(
                             atmWorkHours.last_disconnect
                         )}"></info-item>
                            <info-item text="Վերջին Connect" id='atm_last_connect' value="${formatDate(
                                atmWorkHours.last_connect
                            )}"></info-item>
                        </div> 
                        <div class="info-items">
                            <info-item text="Վերջին ստատուսի տևողություն" id='atm_last_status_duration' value="${
                                atmWorkHours.last_status_duration
                            }"></info-item>
                        </div>


                        <chart-component
                            id="worktime-bar-chart"
                            api-url="/dashboard/atm-worktime-in-days"
                            atm-id="${this.atmId}"
                            grouped
                            chart-type="bar">
                        </chart-component>
                    </div>

                    </div>  
                </div>
            </div>

           <div class="column sm-12">
            <div class="container">
                <div class="select-container">
                    <container-top icon="icon-coins" title="Ինկասացիաներ"></container-top>
                    <select-box-date
                        id="encashment-date"
                        start-date="${this.getAttr("start-date")}"
                        end-date="${this.getAttr("end-date")}"
                    ></select-box-date>
                </div> 

                <div class="row infos infos_margin">
                    <info-card id='failed-amount' title="Չկատարված գործարքների գումար" show-border="true"></info-card>
                    <info-card id='failed-count' title="Չկատարված գործարքների քանակ" show-border="true"></info-card>
                    <info-card id='inc_count' title="Ինկասացիաների քանակ" value-color="color-blue" show-border="true"> </info-card>
                    <info-card id='encachment_amount' title="Լիցքավորված գումար" value-currency="֏" value-color="color-blue" show-border="true"> </info-card>
                    <info-card id='collected_amount' title="Ապալիցքավորված գումար" value-currency="֏" value-color="color-blue" show-border="true"> </info-card>                   
                </div>

                <simple-grid
                    data-source="/encashment/summary?atmIds=${this.atmId}"
                    data-type="encashments"
                    columns='["date_time","atm_address", "added_amount", "collected_amount", "marked_as_empty"]'
                    column-labels='{"date_time":"Ամսաթիվ և ժամ","atm_address":"Բանկոմատի հասցե",
                      "added_amount":"Լիցքավորված գումար","collected_amount":"Ապալիցքավորված գումար","marked_as_empty":"Նշվել է որպես դատարկ"}'
                    column-formatters='{"collected_amount":"currency","added_amount":"currency"}'
                    mode="server"
                    per-page="10">
                </simple-grid>
            </div> 
            </div>
        `;
    }
}

customElements.define("atm-details", AtmDetails);
